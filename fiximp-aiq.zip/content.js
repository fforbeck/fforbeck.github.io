hideHelpButtonForImpression = (e) => {
  let target = e.target;
  let label = target instanceof HTMLAnchorElement ? target.text : "";
  label = target instanceof HTMLButtonElement ? target.innerHTML : label;
  label = label.trim();
  if (label && label.includes("Imprimir")) {
    let iframe = document.getElementById("launcher");
    if (iframe) {
      let helpButton = iframe.contentWindow.document.getElementById("Embed");
      if (helpButton) {
        helpButton.style.display = "none";
        setTimeout(
          (btn) => {
            btn.style.display = "inline";
            console.log("Valeu negadis!");
          },
          5000,
          helpButton
        );
      }
    }
  }
};

document.addEventListener("click", hideHelpButtonForImpression, true);
