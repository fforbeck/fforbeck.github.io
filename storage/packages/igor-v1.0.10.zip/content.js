const linksFinanceiros = [
  "/relatorios/saldos",
  "/financeiro",
  "/relatorios/pracas",
  "/kpi",
];

const menu = {
  dashboard: {
    desc: "Dashboard",
    enabled: false,
    link: "https://painel.aiqfome.com/",
  },
  restaurantes: {
    desc: "Restaurantes",
    enabled: true,
    link: "https://painel.aiqfome.com/restaurantes",
  },
  novoRestaurante: {
    desc: "+ Restaurante",
    enabled: true,
    link: "https://painel.aiqfome.com/restaurante/novo",
  },
  pedidos: {
    desc: "Pedidos",
    enabled: true,
    link: "https://painel.aiqfome.com/pedidos",
  },
  prospectos: {
    desc: "Restaurantes Prospectos",
    enabled: true,
    link: "https://painel.aiqfome.com/restaurantes_prospect",
  },
  fominhas: {
    desc: "Fominhas",
    enabled: true,
    link: "https://painel.aiqfome.com/fominhas",
  },
  administrar: {
    desc: "Administrar",
    enabled: true,
    link: "https://painel.aiqfome.com/",
  },
  relatorios: {
    desc: "Relatórios",
    enabled: true,
    link: "https://painel.aiqfome.com/relatorios",
  },
  financeiro: {
    desc: "Financeiro",
    enabled: false,
    link: "https://painel.aiqfome.com/sistema_usuarios/edit/mail-inbox.html",
  },
  boletos: {
    desc: "Boletos",
    enabled: false,
    link: "https://painel.aiqfome.com/relatorios/dashboard",
  },
  avaliacoes: {
    desc: "Avaliações",
    enabled: true,
    link: "https://painel.aiqfome.com/avaliacoes",
  },
  duvidas: {
    desc: "Dúvidas Frequentes",
    enabled: true,
    link: "https://geraldo.zendesk.com/hc/pt-br",
  },
  meusDados: {
    desc: "Meus dados",
    enabled: false,
    link: "https://painel.aiqfome.com/sistema_usuarios/edit",
  },
  sair: {
    desc: "Sair",
    enabled: true,
    link: "https://painel.aiqfome.com/logout",
  },
};

const hideFinanceiro = (e) => {
  linksFinanceiros
    .map((link) => document.querySelector(`[href="${link}"]`))
    .filter((elem) => elem)
    .forEach((elem) => elem.remove());
};

const hideMenuItens = () => {
  let result = document.evaluate(
    '//*[@id="side-nav"]/li/a',
    document,
    null,
    XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
    null
  );

  let menuLinks = [];
  for (let i = 0; i < result.snapshotLength; i++) {
    let item = result.snapshotItem(i);
    let content = item.innerHTML;
    menuLinks.push({ item, content });
  }

  Object.keys(menu)
    .map((k) => menu[k])
    .filter((m) => !m.enabled)
    .map((m) => m.desc)
    .forEach((desc) => {
      menuLinks
        .filter((m) => m.content.indexOf(desc) > -1)
        .forEach((m) => m.item.remove());
    });

  hideFinanceiro();
};

const users = [
  "aiq.suporte.gpuava@gmail.com",
  "aiq.suporte2.gpuava@gmail.com",
  // "guarapuava@aiqfome.com.br",
];

const getCurrentUser = () => {
  const elem = document.querySelector('[href="#!email"]');
  if (elem) return elem.innerText;
  return "";
};

document.onreadystatechange = () => {
  if (document.readyState == "complete") {
    if (users.includes(getCurrentUser())) hideMenuItens();
  }
};
