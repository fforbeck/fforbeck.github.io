const blockedURLs = [
  "https://painel.aiqfome.com/relatorios/saldos",
  "https://painel.aiqfome.com/financeiro",
  "https://painel.aiqfome.com/notasFiscais",
  "https://painel.aiqfome.com/kpi",
  "https://painel.aiqfome.com/relatorios/pracas",
  "https://painel.aiqfome.com/boletos/administrarConta",
  "https://painel.aiqfome.com/boletos/alterarDadosBancarios",
  "https://painel.aiqfome.com/boletos",
  "https://painel.aiqfome.com/boletos/getSaques",
  "https://painel.aiqfome.com/sistema_usuarios/edit/*",
  "https://painel.aiqfome.com/relatorios/dashboard",
  "https://painel.aiqfome.com/relatorios/saldos",
];

try {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      console.log("Blocked: ", details.url);
      return { redirectUrl: "https://painel.aiqfome.com/restaurantes" };
    },
    { urls: blockedURLs },
    ["blocking"]
  );
} catch (e) {
  console.error(e);
}
